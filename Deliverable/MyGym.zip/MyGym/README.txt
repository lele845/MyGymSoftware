PROGETTO: MyGym 
AUTORI: Cirillo Raffaele - 0512119545
	Giordano Vincenzo - 0512119470
	Aquino Luigi - 0512120291
	Aquino Gerardo - 0512115624

--- DESCRIZIONE ---
Applicazione Web J2EE per la gestione di una palestra.
Pattern: MVC (Model-View-Controller).
Tecnologie: JSP, Servlet, MySQL, HTML/CSS, JavaScript.

--- CONFIGURAZIONE DATABASE ---
1. Importare il file 'MyGym_DB.sql' nel proprio server MySQL.
2. Nome Database: mygym
3. Configurazione accesso DB nel progetto:
   File: src/main/java/com/mygym/model/dao/DriverManagerConnectionPool.java
   Utente default: root
   Password default: Raff&Matt0208

---CREDENZIALI DI TEST ---
Per testare il sistema sono già presenti i seguenti utenti:

1. AMMINISTRATORE (Accesso completo)
   Email: admin@mygym.it
   Password: admin123

2. ISTRUTTORE
   Email: coach@mygym.it
   Password: password

3. CLIENTE (Abbonamento Attivo)
   Email: mario@gmail.it
   Password: 123456

